# Google表單，輸入ID後自動帶入其它欄位資料

Demo：[demo](https://letswritetw.github.io/letswrite-google-forms-id-data/)

筆記文：[Let's Write](https://letswrite.tw/google-forms-id-data/)
